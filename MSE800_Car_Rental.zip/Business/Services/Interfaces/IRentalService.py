from abc import ABC, abstractmethod

class IRentalService(ABC):
    @abstractmethod
    def create_rental(self, rental):
        pass

    @abstractmethod
    def list_rentals(self, include_deleted=False, sort_by="start_date"):
        pass

    @abstractmethod
    def list_active_rentals(self):
        pass

    @abstractmethod
    def approve_rental(self, rental_id):
        pass

    @abstractmethod
    def reject_rental(self, rental_id):
        pass

    @abstractmethod
    def delete_rental(self, rental_id):
        pass
