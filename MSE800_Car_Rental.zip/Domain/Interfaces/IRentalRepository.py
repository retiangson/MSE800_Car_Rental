from abc import ABC, abstractmethod

class IRentalRepository(ABC):
    @abstractmethod
    def add(self, rental): pass

    @abstractmethod
    def get_all(self): pass

    @abstractmethod
    def find_by_id(self, rental_id): pass

    @abstractmethod
    def soft_delete(self, rental_id): pass

    @abstractmethod
    def update_status(self, rental_id, isApproved=None, isActive=None): pass